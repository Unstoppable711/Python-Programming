# Appointment Booking and Reminder System

**Student:** Francis Sakala  
**Roll No:** 25/SCA/BCAC/024  
**Course:** Python Programming (5.0CA101C01H) – BCA, MRIIRS, Faridabad

## Project summary
A simple menu-driven Python application to book, view and cancel appointments, and to check reminders for appointments scheduled for today. Records are saved in a CSV file so they remain available after the program is closed.

## Requirements
- Python 3.8 or later
- No external libraries required

## How to run
1. Open a terminal in this project folder.
2. Run: `python main.py` (on Windows you can also use `py main.py`).
3. Follow the menu shown on screen.

## Features
1. Book an appointment with name, date, time and purpose (rejects past date/time, empty fields and double-booked slots).
2. View all saved appointments.
3. Cancel an appointment using its ID.
4. View reminders for today's appointments.
5. Data stored in `appointments.csv`.

## Python concepts used
Variables and data types, functions, conditional statements, `while` and `for` loops, lists and dictionaries, CSV file handling, date/time validation with `datetime`.

## Project files
- `main.py` – complete source code
- `appointments.csv` – sample data (Francis, Cloddie); the program also creates it automatically
- `sample_output.txt` – console run (Ronald books, Cloddie's appointment is cancelled)
- `output_screenshot.png` – screenshot of the output
- `Project_Report.pdf` – report with summary, source code, output and repository link (editable copy: `Project_Report.docx`)

## GitHub repository
https://github.com/Unstoppable711/Python-Programming
