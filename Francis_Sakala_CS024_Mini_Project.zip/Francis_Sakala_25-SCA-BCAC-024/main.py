"""
Appointment Booking and Reminder System
Python Programming (5.0CA101C01H) - Mini Project

Student: Francis Sakala | Roll No: 25/SCA/BCAC/024

Features:
- Book an appointment
- View all appointments
- Cancel an appointment
- Show reminders for appointments happening today

Data is stored in appointments.csv in the same folder.
"""

import csv
import os
from datetime import datetime, date

FILE_NAME = "appointments.csv"
FIELDS = ["appointment_id", "name", "appointment_date", "appointment_time", "purpose"]


def initialize_file():
    """Create the CSV file with headings if it does not exist."""
    if not os.path.exists(FILE_NAME):
        with open(FILE_NAME, "w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=FIELDS)
            writer.writeheader()


def read_appointments():
    """Return all saved appointments."""
    initialize_file()
    with open(FILE_NAME, "r", newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))


def book_appointment():
    print("\n--- Book an Appointment ---")
    name = input("Enter your name: ").strip()
    if not name:
        print("Name cannot be empty.")
        return

    date_text = input("Enter date (YYYY-MM-DD): ").strip()
    time_text = input("Enter time (HH:MM, 24-hour format): ").strip()
    purpose = input("Enter appointment purpose: ").strip()

    if not purpose:
        print("Purpose cannot be empty.")
        return

    try:
        appointment_date = datetime.strptime(date_text, "%Y-%m-%d").date()
        appointment_time = datetime.strptime(time_text, "%H:%M").time()
    except ValueError:
        print("Invalid date or time format. Please try again.")
        return

    if datetime.combine(appointment_date, appointment_time) < datetime.now():
        print("You cannot book an appointment in the past.")
        return

    # Prevent two bookings at the same date and time
    for item in read_appointments():
        if (item["appointment_date"] == date_text
                and item["appointment_time"] == time_text):
            print("That time slot is already booked. Please choose another time.")
            return

    appointments = read_appointments()
    new_id = max((int(item["appointment_id"]) for item in appointments), default=0) + 1

    new_appointment = {
        "appointment_id": str(new_id),
        "name": name,
        "appointment_date": date_text,
        "appointment_time": time_text,
        "purpose": purpose
    }

    with open(FILE_NAME, "a", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDS)
        writer.writerow(new_appointment)

    print(f"Appointment booked successfully! Your appointment ID is {new_id}.")


def view_appointments():
    print("\n--- All Appointments ---")
    appointments = read_appointments()

    if not appointments:
        print("No appointments found.")
        return

    for item in appointments:
        print(
            f'ID: {item["appointment_id"]} | Name: {item["name"]} | '
            f'Date: {item["appointment_date"]} | Time: {item["appointment_time"]} | '
            f'Purpose: {item["purpose"]}'
        )


def cancel_appointment():
    print("\n--- Cancel an Appointment ---")
    appointments = read_appointments()

    if not appointments:
        print("No appointments available to cancel.")
        return

    appointment_id = input("Enter appointment ID to cancel: ").strip()
    remaining = [item for item in appointments if item["appointment_id"] != appointment_id]

    if len(remaining) == len(appointments):
        print("Appointment ID not found.")
        return

    with open(FILE_NAME, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(remaining)

    print(f"Appointment {appointment_id} cancelled successfully.")


def show_reminders():
    print("\n--- Today's Appointment Reminders ---")
    today = date.today().isoformat()
    todays_appointments = [
        item for item in read_appointments()
        if item["appointment_date"] == today
    ]

    if not todays_appointments:
        print("You have no appointments today.")
        return

    for item in todays_appointments:
        print(
            f'Reminder: {item["name"]}, you have an appointment at '
            f'{item["appointment_time"]} for: {item["purpose"]}.'
        )


def main():
    initialize_file()

    while True:
        print("\n===================================")
        print(" APPOINTMENT BOOKING AND REMINDER")
        print("===================================")
        print("1. Book an appointment")
        print("2. View all appointments")
        print("3. Cancel an appointment")
        print("4. Today's reminders")
        print("5. Exit")

        choice = input("Enter your choice (1-5): ").strip()

        if choice == "1":
            book_appointment()
        elif choice == "2":
            view_appointments()
        elif choice == "3":
            cancel_appointment()
        elif choice == "4":
            show_reminders()
        elif choice == "5":
            print("Thank you for using the Appointment Booking and Reminder System!")
            break
        else:
            print("Invalid choice. Please enter a number from 1 to 5.")


if __name__ == "__main__":
    main()
